#!/bin/sh

open 'http://guide.elm-lang.org'
